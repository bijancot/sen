<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class Home extends CI_Controller {
		public function __construct()
		{
			parent::__construct();
			$this->load->model(['pt_model','lomba_model','peserta_model','Statistik']);	
		}
		public function index(){
			$this->load->helper('form');
			$this->load->library('form_validation');
			
			if ($this->form_validation->run('pendaftaran') == FALSE)
			{
				$data['pt'] = $this->pt_model->get_dropdown();
				$data['lomba'] = $this->lomba_model->get_dropdown();
				//print_r($data['pt']);
				
				$this->load->view('header',$data);
				$this->load->view('index',$data);
				$this->load->view('footer',$data);
				
				} else {
				$data['namatim'] = $this->input->post('namatim');
				$data['idpt'] = $this->input->post('idpt');
				$data['idlomba'] = $_POST['idlomba'];
				
				$this->peserta_model->simpan($data);
				redirect('home');
			}
			
		}
		
		public function tentang(){
			$this->load->view('header');
			$this->load->view('tentang');
			$this->load->view('footer');
		}
		
		public function statistik(){
			$this->load->view('header');
			$x['data']=$this->Statistik->get_all();
		    $x['data2']=$this->Statistik->get_peserta();
		    $x['data3']=$this->Statistik->get_lomba();
		    $x['data4']=$this->Statistik->get_provinsi();
		    $x['data5']=$this->Statistik->get_pt();
		    $x['data6']=$this->Statistik->get_bayar();
		    $x['data7']=$this->Statistik->get_belumverifikasi();
		    $x['data8']=$this->Statistik->get_belumbayar();
		    $x['data9']=$this->Statistik->get_jmlhpeserta();
		    $x['data10']=$this->Statistik->get_jmlhtim();
		    $x['data11']=$this->Statistik->get_jmlhkarya();
			$this->load->view('statistik',$x);
			$this->load->view('footer');
		}
		
		public function info_juri(){
			$this->load->view('header');
			$this->load->view('info_juri');
			$this->load->view('footer');
		}
		
		public function info_lomba(){
			$this->load->view('header');
			$this->load->view('info_lomba');
			$this->load->view('footer');
		}
		
		public function info_webinar(){
			$this->load->view('header');
			$this->load->view('info_webinar');
			$this->load->view('footer');
		}
		
		public function pengumuman(){
			$this->load->view('header');
			$this->load->view('pengumuman');
			$this->load->view('footer');
		}
		
		public function jadwal(){
			$this->load->view('header');
			$this->load->view('jadwal');
			$this->load->view('footer');
		}
	}
