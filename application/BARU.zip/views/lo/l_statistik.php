<!-- Page Heading -->
<div class="row d-sm-flex align-items-center justify-content-between mb-4">
	<div class="col-lg-9">
		<h1 class="h3 mb-0 text-gray-800"><b>Data Statistik LO</b> | LO Kreatif</h1>
	</div>
</div>
<!-- Content Row -->
<div class="row">
	<!-- Earnings (Monthly) Card Example -->
	<div class="col-xl-3 col-md-6 mb-4">
		<div class="card border-left-primary shadow py-2">
			<div class="card-body">
				<div class="row no-gutters align-items-center">
					<div class="col mr-2">
						<div class="text-sm font-weight-bold text-primary text-uppercase mb-1">TIM (TOTAL TIM)</div>
						<div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $tim_semua;?> TIM</div>
					</div>
					<div class="col-auto">
						<i class="fa fa-users fa-2x text-gray-300"></i>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Earnings (Monthly) Card Example -->
	<div class="col-xl-3 col-md-6 mb-4">
		<div class="card border-left-info shadow py-2">
			<div class="card-body">
				<div class="row no-gutters align-items-center">
					<div class="col mr-2">
						<div class="text-sm font-weight-bold text-info text-uppercase mb-1">PT (TOTAL PT)</div>
						<div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_pt;?> PT</div>
					</div>
					<div class="col-auto">
						<i class="fa fa-building-o fa-2x text-gray-300"></i>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Earnings (Monthly) Card Example -->
	<div class="col-xl-3 col-md-6 mb-4">
		<div class="card border-left-warning shadow py-2">
			<div class="card-body">
				<div class="row no-gutters align-items-center">
					<div class="col mr-2">
						<div class="text-sm font-weight-bold text-warning text-uppercase mb-1">Juri (TOTAL JURI)</div>
						<div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_juri;?> Juri</div>
					</div>
					<div class="col-auto">
						<i class="fa fa-gavel fa-2x text-gray-300"></i>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="row mb-3">
    <div class="col-md-12">
        <div class="card shadow">
            <div class="card-body">
                <table id="dataTableX" width="100%" class="table table-stripped table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Bidang Lomba</th>
                            <th>Total TIM</th>
                            <th>Akun Aktif</th>
                            <th>Bayar & Validasi</th>
                            <th>Unggah Karya</th>
                            <th>Verifikasi Berkas</th>
                            <th>Reject</th>
                            <th>Telah Dinilai</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $jtim=0;$jaktif=0;$jbayar=0;$junggah=0;$jberkas=0;$jreject=0; $no=1; foreach ($statistik as $data){?>
                        <tr>
                            <td><?php echo $no;?></td>
                            <td><?php echo $data->namalomba;?></td>
                            <td><?php echo $data->TIM;?></td>
                            <td><?php echo $data->AKTIF;?></td>
                            <td><?php echo $data->BAYAR;?></td>
                            <td><?php echo $data->UNGGAH;?></td>
                            <td><?php echo $data->BERKAS;?></td>
                            <td><?php echo $data->REJECT;?></td>
                            <td></td>
                        </tr>
                        <?php 
                        $jtim = $jtim+$data->TIM;
                        $jaktif = $jaktif+$data->AKTIF;
                        $jbayar = $jbayar+$data->BAYAR;
                        $junggah = $junggah+$data->UNGGAH;
                        $jberkas = $jberkas+$data->BERKAS;
                        $jreject = $jreject+$data->REJECT;
                        $no++; }?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="2"><center>Total</center></th>
                            <th><?php echo $jtim;?></th>
                            <th><?php echo $jaktif;?></th>
                            <th><?php echo $jbayar;?></th>
                            <th><?php echo $junggah;?></th>
                            <th><?php echo $jberkas;?></th>
                            <th><?php echo $jreject;?></th>
                            <th></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#dataTableX').DataTable( {
            "scrollX": true
        } );
    } );
</script>