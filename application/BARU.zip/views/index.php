    <!-- ***** Welcome Area Start ***** -->
    <div class="welcome-area" id="welcome">

        <!-- ***** Header Text Start ***** -->
        <div class="header-text">
            <div class="container">
                <div class="row">
                    <div class="left-text col-lg-6 col-md-6 col-sm-12 col-xs-12" data-scroll-reveal="enter left move 30px over 0.6s after 0.4s">
                        <h1>LOMBA NASIONAL KREATIFITAS MAHASISWA</h1>
                        <h3>LO KREATIF 2020</h3>
                        <p>Diselenggarakan oleh APTISI Wilayah VII Jawa Timur </p>
                        <a href="pendaftaran" class="main-button-slider">Daftar</a>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" data-scroll-reveal="enter right move 30px over 0.6s after 0.4s">
                        <img src="<?=base_url();?>assets/images/slider-icon.png" class="rounded img-fluid d-block mx-auto" alt="First Vector Graphic">
                    </div>
                </div>
            </div>
        </div>
        <!-- ***** Header Text End ***** -->
    </div>
    <!-- ***** Welcome Area End ***** -->


    <!-- ***** Features Big Item Start ***** -->
<?php $this->load->view('pendaftaran1');?>
    <!-- ***** Features Big Item End ***** -->
