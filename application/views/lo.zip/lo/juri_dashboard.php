<!-- Page Heading -->
<div class="row d-sm-flex align-items-center justify-content-between mb-4">
    <div class="col-lg-12">
        <h1 class="h3 mb-0 text-gray-800"><b>LO - Kreatif</b><a href="<?php echo site_url('Juri/Penilaian');?>" class="btn btn-primary shadow-sm pull-right"><i class="fa fa-paint-brush fa-sm text-white-50"></i> Mulai Penilaian</a></h1>
    </div>
</div>

<div class="row mb-4">
    <div class="col-lg-4">
        <div class="row mb-4">
            <div class="col-lg-12">
                <div class="card border-left-success shadow py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-sm font-weight-bold text-success text-uppercase mb-1">Tahap Penilaian</div>
                                <?php if ($get_tahap == false) { echo "<b><center class='h4 mb-0 font-weight-bold'>Belum ada</center></b>";
                            }else{?>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $get_tahap->nama_tahap;?></div>Berakhir <span class="text-danger"><b><?php echo $get_tahap->date_end;}?></b></span>
                            </div>
                            <div class="col-auto">
                                <i class="fa fa-gavel fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-4">
            <div class="col-lg-12">
                <div class="card border-left-primary shadow py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-sm font-weight-bold text-primary text-uppercase mb-1">TIM (Yang harus dinilai)</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $progress;?> / <?php echo $total_tim;?> TIM</div>
                            </div>
                            <div class="col-auto">
                                <i class="fa fa-sitemap fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary text-center">Hai selamat datang, <?php echo $username;?></h6>
            </div>
            <div class="card-body">
                <p class="font-weight-bold text-primary mt-0 mb-1">Bidang LOMBA yang harus dinilai:</p>
                <?php foreach ($daftar_bidang as $key) {?>
                    <p class="ml-2 mt-0 mb-1">- <?php echo $key->namalomba;?></p>
                <?php }?>
                <hr>
                <p>Anda dapat <u>mulai melakukan penilaian</u> dengan menekan tombol <b>"Mulai Penilaian"</b> atau masuk kedalam menu <b>"Lembar Penilaian"</b>. <b>Harap</b> menyelesaikan <u>penilaian</u> <b>sebelum tanggal yang telah ditentukan</b>. Jika terdapat <i>kendala</i> atau <i>masalah</i>, anda dapat <b>menghubungi humas</b> kami:</p>
                <p class="mb-1"><b>A</b>: <i>XXXXXXXXXXX</i></p>
                <p class="mt-0"><b>B</b>: <i>XXXXXXXXXXX</i></p>
            </div>
        </div>
    </div>
</div>