    

    <!-- ***** Footer Start ***** -->

    <footer>

        <div class="container">

            <div class="row">

                <div class="col-lg-7 col-md-12 col-sm-12">

                    <p class="copyright">Copyright © LO KREATIF 2020. All Rights Reserved. 

                

                </div>

                <div class="col-lg-5 col-md-12 col-sm-12">

                    <ul class="social">

                        <li><a href="https://www.facebook.com/LO-Kreatif-2020-105985964590813"><i class="fa fa-facebook"></i></a></li>

                        <li><a href="https://twitter.com/lokreatif2020"><i class="fa fa-twitter"></i></a></li>

                        <li><a href="https://www.instagram.com/lokreatif2020/"><i class="fa fa-instagram"></i></a></li>

                        <li><a href="https://www.youtube.com/channel/UCzqR0-UpePk13OEuV1lKucA"><i class="fa fa-youtube"></i></a></li>

                    </ul>

                </div>

            </div>

        </div>

    </footer>

    

    <!-- jQuery -->



    <!-- Bootstrap -->

    <script src="<?=base_url();?>assets/js/popper.js"></script>

    <script src="<?=base_url();?>assets/js/bootstrap.min.js"></script>



    <!-- Plugins -->
    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/autocomplete/jquery.autocomplete.js'></script>
    <script src="<?=base_url();?>assets/js/owl-carousel.js"></script>

    <script src="<?=base_url();?>assets/js/scrollreveal.min.js"></script>


    <script src="<?=base_url();?>assets/js/jquery.counterup.min.js"></script>

    <script src="<?=base_url();?>assets/js/imgfix.min.js"></script> 

		<script src="<?=base_url();?>assets/js/sweetalert2.all.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>


    <!-- Global Init -->
    <script src="<?=base_url();?>assets/js/custom-js2.js"></script>

  </body>

</html>