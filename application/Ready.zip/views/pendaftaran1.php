
<section class="section" id="about">
	<div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-12 col-sm-12" data-scroll-reveal="enter left move 30px over 0.6s after 0.4s">
                    <img src="<?=base_url();?>assets/images/left-image.png" class="rounded img-fluid d-block mx-auto" alt="App">
                </div>
                <div class="right-text col-lg-5 col-md-12 col-sm-12 mobile-top-fix">
                    <div class="left-heading">
                        <h5>Pendaftaran</h5>
                    </div>
                    <div class="left-text">
											<div class="flash-data" data-flashdata="<?=$this->session->flashdata('success');?>"></div>
										
                        <p>Pendaftaran dibuka mulai tanggal 29 September 2020 sampai pada tanggal 31 Oktober 2020.</p>
                        
<?php
		
    echo form_open("pendaftaran");
    echo form_input('namatim',set_value('namatim'),'','Nama Tim',form_error('namatim'));
		echo form_input('email',set_value('email'),'','Email Ketua Tim',form_error('email'));
		echo form_password('password',set_value('password'),'','Password',form_error('password'));
		echo form_input('nohp',set_value('nohp'),'','No Handphone Ketua Tim',form_error('nohp'));
		
		echo form_dropdown('idpt', $pt,set_value('idpt'),'required="required"','Nama Perguruan Tinggi',form_error('idpt'));
		echo form_dropdown('idlomba', $lomba,set_value('idlomba'),'required="required"','Kategori Lomba',form_error('idlomba'));
   
    echo form_submit('','Daftar','class="btn btn-primary px-5 rounded-pill float-right "');
    echo form_close();
?>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="hr"></div>
			</div>
            </div>
        </div>
    </section>
    
    
<section class="section" id="about">

    <div class="container">

        <h4 class="display-4 text-center" style="color: #007bff;"><strong>Co-Host</strong></h4></br>
     <div class="text-center">
     <img src="/img/cohost/Stiki.png" alt="STIKI" height="100" width="100">
     <img src="/img/cohost/UMM.png" alt="UMM" height="100" width="100">
     <img src="/img/cohost/Hang Tuah.jpg" alt="Hang Tuah" height="100" width="100">
     <img src="/img/cohost/UNTAG.png" alt="UNTAG" height="100" width="100">
     <img src="/img/cohost/UWKS.png" alt="UWKS" height="100" width="100">
     <img src="/img/cohost/UNISMA.png" alt="UNISMA" height="100" width="100">
     <img src="/img/cohost/Logo Narotama.jpg" alt="NAROTAMA" height="100" width="300">
     <img src="/img/cohost/UNIPMA.png" alt="UNIPMA" height="100" width="100">
     <img src="/img/cohost/Adi Buana.png" alt="Adi Buana" height="125" width="100">
     <img src="/img/cohost/UBAYA.png" alt="UBAYA" height="100" width="100">
     </div></br></br></br>
     
             <h4 class="display-4 text-center" style="color: #007bff;"><strong>Media Partners</strong></h4></br>
         <div class="text-center">
     <img src="/img/media/Tirto.png" alt="Tirto" height="100" width="100">
     <img src="/img/media/Andi1.png" alt="Andi1" height="100" width="100">
     <img src="/img/media/Andi2.png" alt="Andi2" height="75" width="75">
     <img src="/img/media/Andi3.png" alt="Andi3" height="75" width="200">
          </div></br></br></br>
     
            <h4 class="display-4 text-center" style="color: #007bff;"><strong>Industry Partners</strong></h4></br>
         <div class="text-center">
     <img src="/img/industry/Sosialoka - Vertical2.png" alt="Sosialoka" height="100" width="100">
     
     </div></br></br>
    </div>
</section>
